# ToneWave Android test shell

This is an **unofficial, independently built Android WebView test app** loading the existing ToneWave Base44 website.

## Limitations
- It does **not** contain or export Base44 source code.
- The website's JavaScript `blob:` audio exports may not download correctly inside Android WebView; must test on device.
- Google Play may reject a website-only wrapper under minimum-functionality rules.
- The release AAB produced by CI is **unsigned** and is NOT ready for Play Console upload. Configure secure release signing before publishing.
- Keep Base44 payments disabled until entitlement provisioning works.
- Ensure the website and its content are yours to distribute.

## Build
Use Gradle 8.10.2, JDK 17, Android SDK platform 35. `gradle :app:assembleDebug` builds an installable debug APK. `gradle :app:bundleRelease` builds an unsigned release AAB.
